library(ggplot)
library(gganimate)
agri=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\agriculturedv.csv")
a1=ggplot(data=agri,aes(Month,GDP))
a1+geom_bar(stat="identity",fill="red")+ggtitle("AGRICULTURE GDP GROWTH DURING COVID")+theme(plot.title = element_text(hjust = 0.5))+transition_states (Month,transition_length=2,state_length=1)+ease_aes('sine-in-out')+theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
 
library(plotly)
com=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\combine.csv")
a9=ggplot(com,aes(mining,construction))+geom_point(color=com$year)+geom_line()+ggtitle("RELATION BETWEEN CONSTRUCTION GDP AND MINING GDP")
ggplotly(a9)

#same graph but different interaction
library(gganimate)
com=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\combine.csv")
a9=ggplot(com,aes(mining,construction))+geom_point(color=com$year)+geom_line()+ggtitle("RELATION BETWEEN CONSTRUCTION GDP AND MINING GDP")+transition_reveal(mining)
a9

library(dplyr)
library(highcharter)
options(highcharter.theme = hc_theme_smpl(tooltip = list(valueDecimals = 2)))
par(mar=c(0.5,0.5,0.5,2))
gva=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\GVAdv.csv")
df <- data.frame( x = gva$Sector,y = gva$CurrentPrice,name = gva$Sector)
hc <- df %>%hchart("pie", hcaes(x = name, y = y),name = "CURRENT PRICES IN DIFFERENT SECTORS" )
hc

library(plotly)
min=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\miningdv.csv")
a2=ggplot(data=min,aes(Month,GDP))
a2=a2+geom_bar(stat="identity",fill="tan")+ggtitle("MINING GDP GROWTH DURING COVID")+theme(plot.title=element_text(hjust=0.5))
ggplotly(a2)


package(zoom)
com=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\combine.csv")
stripchart(com$mining,main="Mining GDP", xlab="GDP",ylab="Mining",method="jitter",col="red",pch=1)
zm()

library(plotly)
com=read.csv("D:\\FALL SEMESTER 21\\Data Visualisation\\project\\combine.csv")
a10=ggplot(com, aes(y=overalgdp))+geom_violin(aes(x=mining),trim = FALSE, fill="yellow")+geom_violin(aes(x=agriculture),trim = FALSE, fill="tan")+geom_violin(aes(x=construction),trim = FALSE, fill="black")+ggtitle("Effect of GDP of different sectors on Overall GDP of India")+theme(plot.title = element_text(hjust = 0.5))+xlab("GDP of different sectors")+ylab("Overall GDP of India")
ggplotly(a10)



